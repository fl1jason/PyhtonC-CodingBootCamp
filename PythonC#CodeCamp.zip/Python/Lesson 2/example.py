################################################################################################################
####
#### Lesson 2: Understanding simple Data Types
####
################################################################################################################

# Start with a simple welcome to tell the user what this program does
print("Add two numbers...")

# Ask for the first number
number1 = int(input ("Please enter your first number"))

# Ask for the second number
number2 = int(input ("Please enter your second number"))

# Work out the result
result = number1 + number2

# Output the answer
print ("Answer: " + str(result))

print ("Was I right?")


