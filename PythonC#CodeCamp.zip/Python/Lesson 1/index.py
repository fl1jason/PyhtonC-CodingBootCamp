################################################################################################################
####
#### Lesson 1: Simple Input, output and variable usage
####
################################################################################################################

# Start with a simple welcome
print("Welcome!")

# Ask for te user's name
name = input ("I'm Python, what's your name?")

# Output a response using the user's name
print ("Hi " + name+ ", how you doing today?")

