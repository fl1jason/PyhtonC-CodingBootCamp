################################################################################################################
####
#### Lesson 8: Simple Classes
####
################################################################################################################

class Calculator:
    Number1 = 0
    Number2 = 0

calc = Calculator()

calc.Number1 = 2
calc.Number2 = 78

print (str(calc.Number1))
print (str(calc.Number2))

